---
preface_schema: '1.0'
title: 'Just a moment...'
source_type: 'Other'
publisher: 'ashpublications.org'
publishing_date: 'Unknown'
authors: []
available_at: 'https://ashpublications.org/blood/article/136/Supplement%201/3/471313/Cost-Effectiveness-of-Polatuzumab-Vedotin-Plus'
availability_status: 'available'
availability_http_code: '200'
availability_checked_at: '2026-04-06'
availability_note: 'Available as at 2026-04-06.'
source_integrity_flag: 'verified'
credibility_tier_value: '1'
credibility_tier_key: 'commentary'
credibility_tier_label: 'Commentary'
credibility_reason: 'commentary_default'
credibility: 'Final Commentary Report'
journal_ranking_source: 'n/a'
journal_sourceid: ''
journal_title: ''
journal_issn: ''
journal_sjr: '0.0'
journal_quartile: ''
journal_rank_global: '0'
journal_categories: ''
journal_areas: ''
journal_high_ranked: 'False'
journal_match_method: 'none'
journal_match_confidence: '0.0'
keywords: []
abstract: 'ashpublications.org Performing security verification This website uses a security service to protect against malicious bots. This page is displayed while the website verifies you are not a bot. Verification successful. Waiting for ashpublications.org to respond Ray ID: 9e7e7aae9b775aa8 Performance and Security by Cloudflare Privacy'
---
# Just a moment...

Source: https://ashpublications.org/blood/article/136/Supplement%201/3/471313/Cost-Effectiveness-of-Polatuzumab-Vedotin-Plus

ashpublications.org

Performing security verification

This website uses a security service to protect against malicious bots. This page is displayed while the website verifies you are not a bot.

Verification successful. Waiting for ashpublications.org to respond

Ray ID:

9e7e7aae9b775aa8

Performance and Security by

Cloudflare

Privacy
